# Craft Spawn Eggs

**To do more useful things with these spawn eggs, you can check out my [Craft Spawner](https://modrinth.com/datapack/craft-spawner) or [Mineable Spawner](https://modrinth.com/datapack/mineable-spawner) datapack/mod**

---

## Spawn egg crafting recipies (77)

You can search with <kbd>ctrl</kbd> + <kbd>f</kbd>
 
### Allay Spawn Egg

![allay spawn egg](https://cdn.modrinth.com/data/cached_images/8b3bf6b75d6a5c82d8b1d90f38f70817e35bab15.png)

### Axolotl Spawn Egg

![axolotl spawn egg](https://cdn.modrinth.com/data/cached_images/5296863e961d9c43fd29c760f43fe27aaf74f6d1.png)

### Bat Spawn Egg

![bat spawn egg](https://cdn.modrinth.com/data/cached_images/c3886b0f4ce04ba6b9e1806dbff9f11883639a80.png)

### Bee Spawn Egg

![bee spawn egg](https://cdn.modrinth.com/data/cached_images/00ed433c1472a635bae582d5f8449984561a456e.png)

### Blaze Spawn Egg

![blaze spawn egg](https://cdn.modrinth.com/data/cached_images/8a1b806cfa9bc528344203854bfc77f35ec64745.png)

### Camel Spawn Egg

![camel spawn egg](https://cdn.modrinth.com/data/cached_images/95c697ad8e0b3a551ff1c3123d9c58a15c653da8.png)

### Cat Spawn Egg

![cat spawn egg](https://cdn.modrinth.com/data/cached_images/99a7286783283cbf146d29dd8d933b7db53855d5.png)

### Cave Spider Spawn Egg

![cave spider spawn egg](https://cdn.modrinth.com/data/cached_images/1b8443700a464c2cd9733abe73ece54117469663.png)

### Chicken Spawn Egg

![chicken spawn egg](https://cdn.modrinth.com/data/cached_images/176a7ceaa94c2ab3ba1029901b6df624229d0ce5.png)

### Cod Spawn Egg

![cod spawn egg](https://cdn.modrinth.com/data/cached_images/77e8ed226d98c940dd482060dc2527940924dede.png)

### Cow Spawn Egg

![cow spawn egg](https://cdn.modrinth.com/data/cached_images/34c00d8abaead66075db9c0af4e4c4cbd1621a59.png)

### Creeper Spawn Egg

![creeper spawn egg](https://cdn.modrinth.com/data/cached_images/c094245e65d3d19056b714c6f368a9bfd10ad220.png)

### Dolphin Spawn Egg

![dolphin spawn egg](https://cdn.modrinth.com/data/cached_images/3121e276d57a9b708e75caad24893a3d21ba3133.png)

### Donkey Spawn Egg

![donkey spawn egg](https://cdn.modrinth.com/data/cached_images/33dd2c44f4e50d82cd09c1b84e0056f5f3f6d706.png)

### Drowned Spawn Egg

![drowned spawn egg](https://cdn.modrinth.com/data/cached_images/11aef0bfd1fc78732fb0cb81b2041715206f888f.png)

### Elder Guardian Spawn Egg

![elder guardian spawn egg](https://cdn.modrinth.com/data/cached_images/e81fce7c910f9e8807119ae879a45394f4d137f3.png)

### Enderman Spawn Egg

![enderman spawn egg](https://cdn.modrinth.com/data/cached_images/3b2760627d3e34f509a2dcd2ecb9228479c89cfc.png)

###  Endermite Spawn Egg

![endermite spawn egg](https://cdn.modrinth.com/data/cached_images/899b29846c05ebd9afc192ba48826e1205674147.png)

### Evoker Spawn Egg

![evoker spawn egg](https://cdn.modrinth.com/data/cached_images/d2214924315a814fd8f41de321e2dc06dd76731e.png)

### Fox Spawn Egg

![fox spawn egg](https://cdn.modrinth.com/data/cached_images/7a56d3ec2adc91c797dfca4e002e814d25db3ca4.png)

### Frog Spawn Egg

![frog spawn egg](https://cdn.modrinth.com/data/cached_images/2bae6e0e7ef4e77b39bd126f54714159c389a988.png)

### Ghast Spawn Egg

![ghast spawn egg](https://cdn.modrinth.com/data/cached_images/7b4739ff4ee4509b7a1893a381af7484150e6993.png)

### Glow Squid Spawn Egg

![glow squid spawn egg](https://cdn.modrinth.com/data/cached_images/ca63777c5b830d1571dcdf607c239baca5102eaf.png)

### Goat Spawn Egg

![goat spawn egg](https://cdn.modrinth.com/data/cached_images/ba4e4f1fd6a8db7cd90f75d7bf5173f4ede59fd4.png)

### Guardian Spawn Egg

![guardian spawn egg](https://cdn.modrinth.com/data/cached_images/bd7c9af0514b5d0e290b690b358fc755491ffbc1.png)

### Hoglin Spawn Egg

![hoglin spawn egg](https://cdn.modrinth.com/data/cached_images/6ad5ae7f3909191b3decfa45edf513a9e38143ae.png)

### Horse Spawn Egg

![horse spawn egg](https://cdn.modrinth.com/data/cached_images/ffbfe1a075e7cd145dbba541d48b59a2bcbc44ce.png)

### Llama Spawn Egg

![llama spawn egg](https://cdn.modrinth.com/data/cached_images/c7ab5b081d22f94a660759c1e6b487c2074bba4f.png)

### Magma Cube Spawn Egg

![magma cube spawn egg](https://cdn.modrinth.com/data/cached_images/ea8e1b85d364356e87e6a173ec26712c703bf4d1.png)

### Mooshroom Spawn Egg

![mooshroom](https://cdn.modrinth.com/data/cached_images/41049498efe33779e5675dbf78072ff2cbefed25.png)

### Mule Spawn Egg

![mule spawn egg](https://cdn.modrinth.com/data/cached_images/b98a5b882b321e83e4b3d4fc2c2bd97d1210142f.png)

### Ocelot Spawn Egg

![ocelot spawn egg](https://cdn.modrinth.com/data/cached_images/b7953f6d529ba267fb6c892c50fa7c9dbc624b85.png)

### Panda Spawn Egg

![panda spawn egg](https://cdn.modrinth.com/data/cached_images/d045258bf327ba39f0fcafc87b630a06c94d79f5.png)

### Parrot Spawn Egg

![parrot spawn egg](https://cdn.modrinth.com/data/cached_images/619fe6d644e5f4f1e3c3c84b3b663512edf57ae5.png)

### Phantom Spawn Egg

![phantom spawn egg](https://cdn.modrinth.com/data/cached_images/95bd1c2defde6ecbaf3e19e015d6da67c3530d08.png)

### Pig Spawn Egg

![pig spawn egg](https://cdn.modrinth.com/data/cached_images/4d61a7ed81fed07af13e9db29c49bb3e65cf83ed.png)

### Piglin Spawn Egg

![piglin spawn egg](https://cdn.modrinth.com/data/cached_images/754f7543eccb2eb640dfe41630b481ed1bf5805c.png)

### Piglin Brute Spawn Egg

![piglin brute spawn egg](https://cdn.modrinth.com/data/cached_images/cc54c8bbecf90568b379b1a8b4a267d849581562.png)

### Pillager Spawn Egg

![pillager spawn egg](https://cdn.modrinth.com/data/cached_images/71939185a8e43355213922e4dde6666bbef55aa0.png)

### Polar Bear Spawn Egg

![polar bear spawn egg](https://cdn.modrinth.com/data/cached_images/69d3d225bdc758977faec4245a1c3b97630a00ef.png)

### Pufferfish Spawn Egg

![pufferfish spawn egg](https://cdn.modrinth.com/data/cached_images/717964728d6f79b461f328850f0b939ad764de5f.png)

### Rabbit Spawn Egg

![rabbit spawn egg](https://cdn.modrinth.com/data/cached_images/80769799564bdc74242d61436a752a5e77efd3fb.png)

### Ravager Spawn Egg

![ravager spawn egg](https://cdn.modrinth.com/data/cached_images/6e84ca38548c6367188ec07eaf28da0fe6124346.png)

### Salmon Spawn Egg

![salmon spawn egg](https://cdn.modrinth.com/data/cached_images/1b8afaf36ff273d83d7204ceee438a07f70e697b.png)

### Sheep Spawn Egg

**(WIP)** _Use any wool color you want_ **(WIP)**

![sheep spawn egg](https://cdn.modrinth.com/data/cached_images/6a39c888b4609b3851259576da50cb2d581b65db.png)

### Shulker Spawn Egg

![shulker spawn egg](https://cdn.modrinth.com/data/cached_images/10a9f7f51447bea56b6c6a823deac1c0a81b8fa1.png)

### Silverfish Spawn Egg

![silverfish spawn egg](https://cdn.modrinth.com/data/cached_images/c604506d2bf482b378f0addda830ae26e9d3b429.png)

(normal stone brick)

### Skeleton Spawn Egg

![skeleton spawn egg](https://cdn.modrinth.com/data/cached_images/db31391b83e5252afe2ebb66964faca887f634bb.png)

### Skeleton Horse Spawn Egg

![skeleton horse spawn egg](https://cdn.modrinth.com/data/cached_images/3d5badba3efb4cc28cf7b7c7b34baa858e539ea9.png)

### Slime Spawn Egg

![slime spawn egg](https://cdn.modrinth.com/data/cached_images/48879e04c4ed0f2e8184e634a3f94f56b84a90a4.png)

### Sniffer Spawn Egg

![sniffer spawn egg](https://cdn.modrinth.com/data/cached_images/f81c76a843ce19f7cee269945cd43de6a574a47e.png)

### Snow Golem Spawn Egg

![snow golem spawn egg](https://cdn.modrinth.com/data/cached_images/bb2ebda2dd4715596c94d47c1d6807cc01ac2f8e.png)

### Spider Spawn Egg

![spider spawn egg](https://cdn.modrinth.com/data/cached_images/16f67a2751dbe7db8d7a00ff22848282f1757c31.png)

### Squid Spawn Egg

![squid spawn egg](https://cdn.modrinth.com/data/cached_images/0a1658acdfa263f9364ba1c927cf2003b0a6c651.png)

### Stray Spawn Egg

![stray spawn egg](https://cdn.modrinth.com/data/cached_images/dee47b78cf4df9acf46d96e47e7417b85b8636ef.png)

### Strider Spawn Egg

![strider spawn egg](https://cdn.modrinth.com/data/cached_images/e900de4cd1417ed61da5c8c32995cf0d6b0966d1.png)

### Tadpole Spawn Egg

![tadpole spawn egg](https://cdn.modrinth.com/data/cached_images/1575566e1e37dc56d3e44bef8d6dfaea60d24e4a.png)

### Trader Llama Spawn Egg

**(WIP)** _Use any carpet color you want_ **(WIP)**

![trader llama spawn egg](https://cdn.modrinth.com/data/cached_images/be152176936312cdc990ee970a4035c5a522836f.png)

### Tropical Fish Spawn Egg

![tropical fish spawn egg](https://cdn.modrinth.com/data/cached_images/0fc59865dad72cf1052455f0d8dbbc1dd3e4f9ef.png)

### Turtle Spawn Egg

![turtle spawn egg](https://cdn.modrinth.com/data/cached_images/3912dc88b98e9092f59f8e7a0a6d5dac4193789c.png)

### Vex Spawn Egg

added diamond to not make this too OP and annoying

![vex spawn egg](https://cdn.modrinth.com/data/cached_images/a1b96b5bf8a8fc7ef8a37899605628022423bec8.png)

### Villager Spawn Egg

![villager spawn egg](https://cdn.modrinth.com/data/cached_images/93253179f3a3435d53beb9566d0fc44bc0600db3.png)

### Vindicator Spawn Egg

![vindicator spawn egg](https://cdn.modrinth.com/data/cached_images/fbdccedd06aa04ada1cfe1516236468695ed66cb.png)

### Wandering Trader Spawn Egg

![wandering trader spawn egg](https://cdn.modrinth.com/data/cached_images/f33a0bac70f42e9c441cf927c4ffe9563ee550a0.png)

### Warden Spawn Egg

![warden spawn egg](https://cdn.modrinth.com/data/cached_images/1ba5f49e63de955123cd3b37d5bc9f9571662683.png)

### Witch Spawn Egg

![witch spawn egg](https://cdn.modrinth.com/data/cached_images/6c82aa931ba72cc7566da1d6d8b4086c0645746d.png)

### Wither Skeleton Spawn Egg

![wither skeleton spawn egg](https://cdn.modrinth.com/data/cached_images/bb075acad8dd95cbbc930613f69ad4c56d97b178.png)

### Wolf Spawn Egg

![wolf spawn egg](https://cdn.modrinth.com/data/cached_images/ea906634e626a929f0deebbbd375259f5aafa9bb.png)

### Zoglin Spawn Egg

![zoglin spawn egg](https://cdn.modrinth.com/data/cached_images/d5700d5a8de527f0b5c37daf5e8248bc8addc7a8.png)

### Zombie Spawn Egg

![zombie spawn egg](https://cdn.modrinth.com/data/cached_images/1b2e40ff1761b5b6af51f206f789c9b07f2c1a80.png)

### Zombie Horse Spawn Egg

![zombie horse spawn egg](https://cdn.modrinth.com/data/cached_images/9ead180d989cf4e2b16cf2a1a7cbe95365962645.png)

### Zombie Villager Spawn Egg

![ombie villager spawn egg](https://cdn.modrinth.com/data/cached_images/ca84d27e4cc49a2002134a94a5d5179098e1d276.png)

### Zombiefied Piglin Spawn Egg

![zombified piglin spawn egg](https://cdn.modrinth.com/data/cached_images/96f61294aa1f132dfa25e317ba44369591a1e9f1.png)

---

## Datapack created by Jodek published on modrinth: https://modrinth.com/user/Jodek

<picture>
   <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/Mqxx/GitHub-Markdown/main/blockquotes/badge/light-theme/tip.svg">
  <img alt="Tip" src="https://raw.githubusercontent.com/Mqxx/GitHub-Markdown/main/blockquotes/badge/dark-theme/tip.svg">
 </picture><br>
 
Questions or issues? -> [discord server](https://discord.gg/z2n3qTzQY6) | _or create an issue on github_
